/* $Id */

/* Support for creating declarations and definitions from one statement */
/* This particular module starts definitions */

/* This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log
 */

#define GLOBAL
#define INITIALLY(value) = value
#define INITIALLY1(a) = {a}
#define INITIALLY2(a,b) = {a,b}
#define INITIALLY3(a,b,c) = {a,b,c}
#define INITIALLY4(a,b,c,d) = {a,b,c,d}
#define INITIALLY5(a,b,c,d,e) = {a,b,c,d,e}
#define INITIALLY6(a,b,c,d,e,f) = {a,b,c,d,e,f}
#define INITIALLY7(a,b,c,d,e,f,g) = {a,b,c,d,e,f,g}
#define INITIALLY8(a,b,c,d,e,f,g,h) = {a,b,c,d,e,f,g,h}
#define INITIALLY9(a,b,c,d,e,f,g,h,i) = {a,b,c,d,e,f,g,h,i}
#define INITIALLY10(a,b,c,d,e,f,g,h,i,j) = {a,b,c,d,e,f,g,h,i,j}
#define INITIALLY11(a,b,c,d,e,f,g,h,i,j,k) = {a,b,c,d,e,f,g,h,i,j,k}
#define INITIALLY12(a,b,c,d,e,f,g,h,i,j,k,l) = {a,b,c,d,e,f,g,h,i,j,k,l}
