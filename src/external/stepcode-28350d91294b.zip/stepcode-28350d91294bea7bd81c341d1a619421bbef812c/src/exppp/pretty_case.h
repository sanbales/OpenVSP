#ifndef PRETTY_CASE_H
#define PRETTY_CASE_H

#include <express/stmt.h>

void CASEout( struct Case_Statement_ * c, int level );

#endif /* PRETTY_CASE_H */
