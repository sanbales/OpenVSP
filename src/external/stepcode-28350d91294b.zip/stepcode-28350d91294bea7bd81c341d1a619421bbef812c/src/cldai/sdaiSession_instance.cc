#include <sdai.h>
#include "sc_memmgr.h"

SDAI_Session_instance::SDAI_Session_instance() {
}

SDAI_Session_instance::~SDAI_Session_instance() {
}
